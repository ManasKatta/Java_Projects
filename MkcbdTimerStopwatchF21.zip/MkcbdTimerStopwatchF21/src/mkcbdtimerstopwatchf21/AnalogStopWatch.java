/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mkcbdtimerstopwatchf21;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Duration;

/**
 *
 * @author manas
 * most of the code is taken from lecture on 9/20/21 and subsequent lectures
 */
public class AnalogStopWatch 
{
    private double secondsElapsed = 0.0;
    private double tickTimeInSeconds = 0.01; //how to change the resolution
    private double angleDeltaPerSeconds = 6.0;
    private static int recordCount;
    private Timeline timeline;
    private KeyFrame keyFrame;
    private TextArea lapField;
    private String itsOver = "Times up!";
    private VBox root;
    private ImageView dialImageView;
    private ImageView handImageView;
    private Image handImage;
    private Image dialImage;
    private String dialImageName;
    private String handImageName;
    private Button startStop;
    private Button resetRecord;
    private TextInputDialog prompt;
    private Text secondsElapsedDisplayed;
    private Text timerDisplay;
    boolean wasItRunning;
    boolean resetFlag;
    private boolean success = true;
    
    public AnalogStopWatch()
    {   
        prompt = new TextInputDialog("Enter your desired time");
        prompt.setTitle("Timer Start Time Setup");
        prompt.setHeaderText("Setup the Start Time");
        prompt.setContentText("Please set up the start time (Integer)");
        prompt.showAndWait();
        
        while(isStringInt(prompt.getEditor().getText()) == false)
        {
            
            Alert wrongNumbers = new Alert(AlertType.ERROR);
            wrongNumbers.setContentText("Please enter a valid integer");
            wrongNumbers.showAndWait();
            prompt.showAndWait();
            
        }
        setupUI();
        setupTimer();
            
        
    }
    
    //the following method is taken from https://stackoverflow.com/questions/12558206/how-can-i-check-if-a-value-is-of-type-integer
    public boolean isStringInt(String s)
    {
        try
        {
            Integer.parseInt(s);
            return true;
        } catch (NumberFormatException ex)
        {
            return false;
        }
    }
    
    public void setupUI()
    {
        root = new VBox();
        root.setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 0), CornerRadii.EMPTY, Insets.EMPTY)));
        StackPane analog = new StackPane();
        dialImageView = new ImageView();
        handImageView = new ImageView();
        ImageView background = new ImageView();
       

        Image bg = new Image(getClass().getResourceAsStream("MkcbdTimerStopwatchF21-AuroraBorealis.jpg"));
        //adding the analog clock image and background
        dialImage = new Image(getClass().getResourceAsStream("MkcbdTimerStopwatchF21-Rolex.png"));
        handImage = new Image(getClass().getResourceAsStream("MkcbdTimerStopwatchF21-hand.png"));
        dialImageView.setImage(dialImage);
        handImageView.setImage(handImage);
        background.setImage(bg);
        background.setFitHeight(700);
        background.setFitWidth(1000);
        handImageView.setFitHeight(550);
        handImageView.setFitWidth(550);
        analog.getChildren().addAll(background, dialImageView, handImageView);
        root.getChildren().addAll(analog);
        
        
        
        // butttons for display
        VBox controlButtons = new VBox();
        controlButtons.setBackground(new Background(new BackgroundFill(Color.rgb(0, 0, 0), CornerRadii.EMPTY, Insets.EMPTY)));
        startStop = new Button("Start");
        startStop.setStyle("-fx-background-color: #00DF96; ");
        resetRecord = new Button("Record");
        resetRecord.setStyle("-fx-background-color: #017ed5; ");
        startStop.setMaxWidth(Double.MAX_VALUE);
        resetRecord.setMaxWidth(Double.MAX_VALUE);
        controlButtons.setAlignment(Pos.BOTTOM_CENTER);
        controlButtons.setSpacing(10);
        controlButtons.setPadding(new Insets(25,25,25,25));
        controlButtons.getChildren().addAll(resetRecord, startStop);
        root.getChildren().add(controlButtons);
        
        //labels and text entities
        Label secondsDisplayLabel = new Label("Seconds Elapsed");
        secondsDisplayLabel.setTextFill(Color.web("#017ed5"));
        secondsElapsedDisplayed = new Text("0.0");
        secondsElapsedDisplayed.setFill(Color.web("#017ed5"));
        root.getChildren().addAll(secondsDisplayLabel, secondsElapsedDisplayed);
        Label timerLabel = new Label("Timer");
        timerDisplay = new Text(prompt.getEditor().getText());
        timerLabel.setTextFill(Color.web("#00DF96"));
        timerDisplay.setFill(Color.web("#00DF96"));
        root.getChildren().addAll(timerLabel, timerDisplay);
        
        //Records/Laps and associated entities
        lapField = new TextArea();
      
        lapField.setStyle("-fx-text-inner-color: #00DF96;");
       
        lapField.setStyle("-fx-control-inner-background: black;");
        Label laps = new Label("Laps");
        laps.setTextFill(Color.web("#b53dff"));
        root.getChildren().add(laps);
        root.getChildren().add(lapField);
        
      
        
        
        startStop.setOnAction((ActionEvent event) -> {
            if(isRunning())
            {
                stop();
            }
            else
            {
                start();
            }
        });
        
        
        resetRecord.setOnAction((ActionEvent event) -> {
            if(timerDisplay.getText() == itsOver && isRunning() == true)
            {
                Alert a = new Alert(AlertType.INFORMATION);
                a.setContentText(itsOver);
                a.show();
            }
            else if(isRunning())
            {
                record();
            }
            else
            {
                //reset
                timeline.stop();
                handImageView.setRotate(0);
                secondsElapsed = 0;
                startStop.setText("Start");
                prompt.setContentText("Please set up the new start time (Integer)");
                prompt.showAndWait();
                while(isStringInt(prompt.getEditor().getText()) == false)
                {

                    Alert wrongNumbers = new Alert(AlertType.ERROR);
                    wrongNumbers.setContentText("Please enter a valid integer");
                    wrongNumbers.showAndWait();
                    prompt.showAndWait();

                }
                timerDisplay.setText(prompt.getEditor().getText());
                secondsElapsedDisplayed.setText("0.0");
                lapField.clear();
                
              
            }
        });
        
    }
    // taken from video from previous semester
    public void setupTimer()
    {
        
        
            if(isRunning())
            {
                timeline.pause();
                wasItRunning = true;
            }
            keyFrame = new KeyFrame(Duration.millis(1000 * tickTimeInSeconds), (ActionEvent actionEvent) -> {
               update();
               
            });

            timeline = new Timeline(keyFrame);
            timeline.setCycleCount(Animation.INDEFINITE);

            if(wasItRunning)
            {
                timeline.play();
                wasItRunning = false;
            }
        
    }
    //update is taken from Lecture on the monday the challenge was assigned
    private void update()
    {
       NumberFormat formatter = new DecimalFormat("#0.00"); 
       if(timerDisplay.getText() == itsOver) 
       {
           secondsElapsed += tickTimeInSeconds;
           double rotation = secondsElapsed * angleDeltaPerSeconds;
           handImageView.setRotate(rotation);
           secondsElapsedDisplayed.setText(String.valueOf(formatter.format(secondsElapsed)));
           //timeline.pause();
           timerDisplay.setText(itsOver);
       }
       else if(Double.parseDouble(timerDisplay.getText()) > 0)
       {
           //System.out.println("Timeline event!");
           //System.out.println(timerDisplay.getText());
           secondsElapsed += tickTimeInSeconds;
           double rotation = secondsElapsed * angleDeltaPerSeconds;
           double result = Double.valueOf(prompt.getEditor().getText()) - secondsElapsed;
           handImageView.setRotate(rotation);
          
           secondsElapsedDisplayed.setText(String.valueOf(formatter.format(secondsElapsed)));
           secondsElapsedDisplayed.setFill(Color.web("#017ed5"));
           
           timerDisplay.setText(String.valueOf(formatter.format(result)));
           timerDisplay.setFill(Color.web("#00DF96"));
          
       }
       else
       {
           timerDisplay.setText(itsOver);
       }
       
       
        
        
    }
    
    
    private void record()
    {
        recordCount++;
        
        if(recordCount == 1)
        {
            String champ = "Champion ♛: " + String.valueOf(secondsElapsed) + "\n";
            lapField.appendText(champ);
            
        }
        String lap = "Lap " + String.valueOf(recordCount) + ": " + String.valueOf(secondsElapsed) + "\n";
        lapField.appendText(lap);
    }
    
    public boolean isRunning()
    {
        if(timeline != null)
        {
            if(timeline.getStatus() == Animation.Status.RUNNING)
            {
                return true;
            }
        }
        
        return false;
    }
    
    
    public Parent getRoot()
    {
        return root;
    }
    
    public void setTickTimeInSeconds(Double tickTimeInSeconds)
    {
        this.tickTimeInSeconds = tickTimeInSeconds;
        setupTimer();
    }
    
    public void start()
    {
        timeline.play();
        startStop.setText("Stop");
        resetRecord.setText("Record");
        startStop.setStyle("-fx-background-color: #ED2603; ");
    }
    
    public void stop()
    {
        timeline.pause();
        startStop.setText("Play");
        resetRecord.setText("Reset");
        startStop.setStyle("-fx-background-color: #00DF96; ");
    }
}

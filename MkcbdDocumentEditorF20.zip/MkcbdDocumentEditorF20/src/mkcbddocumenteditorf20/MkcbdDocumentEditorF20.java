/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mkcbddocumenteditorf20;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;


/**
 *
 * @author Professor Wergeles
 */
public class MkcbdDocumentEditorF20 extends Application {
    
    public String title = "Document Editor 2";
    public int width = 800; 
    public int height = 700; 
    
    @Override
    public void start(Stage primaryStage) {
        
        primaryStage.setTitle(title);
        
        VBox root = new VBox(20); 
        
        GridPane grid = new GridPane(); 
        grid.setAlignment(Pos.CENTER);
        grid.setVgap(20);
        
        Label titleLabel = new Label("Title:");
        TextField titleField = new TextField(); 
        titleField.setPrefColumnCount(45);
        HBox titleFieldBox = new HBox(10); 
        titleFieldBox.setAlignment(Pos.CENTER_LEFT);
        titleFieldBox.getChildren().addAll(titleLabel, titleField); 
        grid.add(titleFieldBox, 0, 0);
        
        TextArea editor = new TextArea(); 
        editor.setPrefColumnCount(45); 
        editor.setPrefRowCount(25); 
        grid.add(editor, 0, 1);    
        
        MenuBar menuBar = new MenuBar(); 
        Menu fileMenu = new Menu("File"); 
        menuBar.getMenus().add(fileMenu); 
        MenuItem saveMenuItem = new MenuItem("Save"); 
        MenuItem openMenuItem = new MenuItem("Open");
        fileMenu.getItems().addAll(openMenuItem, saveMenuItem); 
        
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save");
        
        fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Text Documents", "*.txt"));
        

        // save method is taken from https://www.genuinecoder.com/save-files-javafx-filechooser/
        saveMenuItem.setOnAction((ActionEvent event) -> 
        {
            fileChooser.setInitialFileName(titleField.getText());
            try 
            {
                File file = fileChooser.showSaveDialog(primaryStage);
                PrintWriter writer;
                writer = new PrintWriter(file);
                writer.println(editor.getText());
                writer.close();
            } catch (FileNotFoundException ex) 
            {
                Logger.getLogger(MkcbdDocumentEditorF20.class.getName()).log(Level.SEVERE, null, ex);
            }
          
        });
        
        // open method is taken from https://stackoverflow.com/questions/4716503/reading-a-plain-text-file-in-java
        openMenuItem.setOnAction((ActionEvent event) ->
        {
            File openFile = fileChooser.showOpenDialog(primaryStage);
            try(BufferedReader br = new BufferedReader(new FileReader(openFile))) 
            {
                StringBuilder sb = new StringBuilder();
                String line = br.readLine();

                while (line != null) {
                    sb.append(line);
                    sb.append(System.lineSeparator());
                    line = br.readLine();
                }
                String everything = sb.toString();
                editor.appendText(everything);
                titleField.appendText(openFile.getName());
            } 
            catch (FileNotFoundException ex) 
            {
                Logger.getLogger(MkcbdDocumentEditorF20.class.getName()).log(Level.SEVERE, null, ex);
            } 
            catch (IOException ex) 
            {
                Logger.getLogger(MkcbdDocumentEditorF20.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        root.getChildren().addAll(menuBar, grid); 
        
        Scene scene = new Scene(root, width, height); 
        primaryStage.setScene(scene);
        
        primaryStage.show(); 
    }

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    } 
}
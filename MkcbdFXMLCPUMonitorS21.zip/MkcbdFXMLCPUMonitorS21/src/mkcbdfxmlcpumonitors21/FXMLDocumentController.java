/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//most if not all of the code is heavily inspired by the stopwatch challenge and all the sources used in that.
package mkcbdfxmlcpumonitors21;

import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.util.Duration;

/**
 *
 * @author manas
 */
public class FXMLDocumentController implements Initializable {
    private Timeline timeline;
    double cumCPU = 0; 
    private KeyFrame keyFrame;
    private int lineRecordCount= 1;
    private int areaRecordCount = 1;
    private double max = getCPUUsage();
    boolean wasItRunning;
    private double tickTimeInSeconds = .01;
    XYChart.Series lineSeries = new XYChart.Series(); 
    XYChart.Series areaSeries = new XYChart.Series(); 
    @FXML
    private Label label;
    @FXML
    private LineChart lineGraph;
    @FXML
    private Button startStop;
    @FXML
    private Button resetRecord;
    @FXML
    private ImageView myHandImage;
    @FXML
    private Text cpuUsageDisplay;
    @FXML
    private AreaChart areaGraph;
    @FXML
    private Text peakCPUText;
    @FXML
    private Text avgCPUText;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        startStop.setMaxWidth(Double.MAX_VALUE);
        resetRecord.setMaxWidth(Double.MAX_VALUE);
        lineGraph.getData().add(lineSeries);
        areaGraph.getData().add(areaSeries);
        lineGraph.setTitle("Recorded CPU Usage");
        areaGraph.setTitle("MEAN CPU LOAD");
        
        
        setupTimer();
    }    
    
    
    
    
    public boolean isRunning()
    {
        if(timeline != null)
        {
            if(timeline.getStatus() == Animation.Status.RUNNING)
            {
                return true;
            }
        }
        
        return false;
    }
    
    private void record()
    {
        
        
        //lineGraph.setAnimated(false);
        lineSeries.getData().add(new XYChart.Data(Integer.toString(lineRecordCount), getCPUUsage()*100));
        lineRecordCount++;
        lineGraph.setAnimated(false);
       
        
    }
    
    @FXML
    void startStopPressed(ActionEvent event)
    {
        if(isRunning())
            {
                stop();
            }
            else
            {
                start();
            }
    }
    
    @FXML
    void resetRecordPressed(ActionEvent event)
    {
        if(isRunning())
            {
                record();
            }
            else
            {
                reset();
            }
    }
   
    public double getCPUUsage() {
        OperatingSystemMXBean operatingSystemMXBean = ManagementFactory.getOperatingSystemMXBean();
        double value = 0;
        
        for(Method method : operatingSystemMXBean.getClass().getDeclaredMethods()) {
            method.setAccessible(true);
            
            if (method.getName().startsWith("getSystemCpuLoad") && Modifier.isPublic(method.getModifiers())) {
                try {
                    value = (double) method.invoke(operatingSystemMXBean);
                } catch (Exception e) {
                    value = 0;
                }
                return value;
            }
        }
        return value;
    }
    public void start()
    {
        timeline.play();
        startStop.setText("Stop");
        resetRecord.setText("Record");
        startStop.setStyle("-fx-background-color: #ED2603; "); //red
        resetRecord.setStyle("-fx-background-color: #017ed5; "); //blue
    }
    
    public void stop()
    {
        timeline.pause();
        startStop.setText("Play");
        resetRecord.setText("Reset");
        startStop.setStyle("-fx-background-color: #00DF96; "); //green
        resetRecord.setStyle("-fx-background-color: #FFFF00; "); //yellow
    }
    
    public void setupTimer()
    {
        
        
            if(isRunning())
            {
                timeline.pause();
                wasItRunning = true;
            }
            keyFrame = new KeyFrame(Duration.millis(1000 * tickTimeInSeconds), (ActionEvent actionEvent) -> {
               update();
               
            });

            timeline = new Timeline(keyFrame);
            timeline.setCycleCount(Animation.INDEFINITE);

            if(wasItRunning)
            {
                timeline.play();
                wasItRunning = false;
            }
        
    }
    private void update()
    {
        double rotation = getCPUUsage() * 100;
        myHandImage.setRotate((rotation*3)-164.1);  
        String value = String.format("%.2f", rotation) + "%";
        cpuUsageDisplay.setText(value);
        
        
        maxCPU();
        String formattedPeakCPU = String.format("%.2f", max*100) + "%";
        peakCPUText.setText(formattedPeakCPU);
        
       
        cumCPU += getCPUUsage();
        double avg = cumCPU/areaRecordCount;
        avgCPUText.setText(String.format("%.2f", avg*100) + "%");
        //areaGraph.setAnimated(false);
        areaSeries.getData().add(new XYChart.Data(Integer.toString(areaRecordCount), avg*100));
        areaRecordCount++;
        areaGraph.setAnimated(false);
    
        
        
        
    }
    
    private void maxCPU()
    {
        
        double candidate = getCPUUsage();
        if(candidate > max)
        {
            max = candidate;
        }
        
    }
    
    private void reset()
    {
        //lineGraph.getData().clear();
        //areaGraph.getData().clear();
        myHandImage.setRotate(-164.1);
        peakCPUText.setText("0.0%");
        avgCPUText.setText("0.0%");
        cpuUsageDisplay.setText("0.0%");
        lineSeries.getData().clear();
        areaSeries.getData().clear();
        cumCPU = 0;
        max = 0;
        lineRecordCount = 1;
        areaRecordCount = 1;

    }
}


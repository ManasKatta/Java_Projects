/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mkcbdgpacalculatorf21;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.lang.Math;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

/**
 *
 * @author manas
 */
public class MkcbdGPACalculatorF21 extends Application 
{   
    private String title = "GPA Calculator";
    private int width = 500;
    private int height = 425;
    
    private String sceneTitleText = "Welcome Please Enter GPA";
    private String fontStyle = "Comic Sans MS";
    
    
    
    @Override
    public void start(Stage primaryStage) 
    {
        //most if not all of the following is taken from the lecture on 9/13/21 some from following lectures
        GridPane root = new GridPane();
        root.setAlignment(Pos.BASELINE_CENTER);
        root.setVgap(10);
        root.setHgap(10);
        root.setPadding(new Insets(15,15,15,15));
        
        Text sceneTitle = new Text(sceneTitleText);
        sceneTitle.setFont(Font.font(fontStyle, FontWeight.BOLD, 26));
       //root.add(sceneTitle, 0, 0);
       //root.add(sceneTitle,0,0,2,1);
      
                
        primaryStage.setTitle(title);        
        
        //Course 1        
        Label course1 = new Label("Course 1: ");
        sceneTitle.setFont(Font.font(fontStyle, FontWeight.NORMAL, 18));
        root.add(course1, 0, 0, 1, 1);
        
        TextField score1 = new TextField();
        score1.setPrefWidth(350);
        root.add(score1, 1, 0, 1, 1);
        
        //Course 2
        Label course2 = new Label("Course 2: ");
        sceneTitle.setFont(Font.font(fontStyle, FontWeight.NORMAL, 18));
        root.add(course2, 0, 1, 1, 1);
        
        TextField score2 = new TextField();
        score2.setPrefWidth(350);
        root.add(score2, 1, 1, 1, 1);
        
        //Course 3
        Label course3 = new Label("Course 3: ");
        sceneTitle.setFont(Font.font(fontStyle, FontWeight.NORMAL, 18));
        root.add(course3, 0, 2, 1, 1);
        
        TextField score3 = new TextField();
        score3.setPrefWidth(350);
        root.add(score3, 1, 2, 1, 1);
        
        //Course 4
        Label course4 = new Label("Course 4: ");
        sceneTitle.setFont(Font.font(fontStyle, FontWeight.NORMAL, 18));
        root.add(course4, 0, 3, 1, 1);
        
        TextField score4 = new TextField();
        score4.setPrefWidth(350);
        root.add(score4, 1, 3, 1, 1);
        
        
        //TextArea
        Label textLabel = new Label("Information: ");
        root.add(textLabel, 0, 4, 2, 1);
        TextArea infoBox = new TextArea();
        infoBox.setPrefRowCount(3);
        infoBox.setWrapText(true);
        infoBox.setEditable(false);
        root.add(infoBox, 0, 5, 2, 1);
        
        //VBox
        VBox buttonBox = new VBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        //buttons creation
        Button gpaCalc = new Button();
        gpaCalc.setText("Calculate GPA");
        Button showStats = new Button();
        showStats.setText("Show Statistics");
        Button alert = new Button();
        alert.setText("Alert");
        Button clearAll = new Button();
        clearAll.setText("Clear All");
     
        buttonBox.getChildren().add(gpaCalc);
        buttonBox.getChildren().add(showStats);
        buttonBox.getChildren().add(alert);
        buttonBox.getChildren().add(clearAll);
        gpaCalc.setMaxWidth(Double.MAX_VALUE);
        showStats.setMaxWidth(Double.MAX_VALUE);
        alert.setMaxWidth(Double.MAX_VALUE);
        clearAll.setMaxWidth(Double.MAX_VALUE);
        
        root.add(buttonBox, 0, 6, 2, 1);
         
        
        //Calculate GPA Button
        gpaCalc.setOnAction
        (
          new EventHandler<ActionEvent>() 
            {
                @Override
                public void handle(ActionEvent event)
                {
                    try
                    {
                        int numOfScores = 4;
                        int course1Grade = Integer.parseInt(score1.getText());
                        int course2Grade = Integer.parseInt(score2.getText());
                        int course3Grade = Integer.parseInt(score3.getText());
                        int course4Grade = Integer.parseInt(score4.getText());
                        
                        if(course1Grade > 100 || course1Grade < 0 || course2Grade > 100 || course2Grade < 0 || course3Grade > 100 || course3Grade < 0 || course4Grade > 100 || course4Grade < 0 )
                        {
                            Alert wrongNumbers = new Alert(AlertType.ERROR);
                            wrongNumbers.setContentText("Insert only integer numbers from 0 to 100");
                            wrongNumbers.show();
                        }
                        else
                        {
                            int avg = (course1Grade + course2Grade + course3Grade + course4Grade)/numOfScores;


                            if (avg >= 87 && avg <= 100)
                            {
                                infoBox.clear();
                                infoBox.appendText("Your average score is: ((" + course1Grade + "+" + course2Grade + "+" + course3Grade + "+" + course4Grade + ")/4) = " + avg);
                                infoBox.appendText("\nYour Grade is A");
                            }
                            else if (avg >= 77 && avg < 87)
                            {
                                infoBox.clear();
                                infoBox.appendText("Your average score is: ((" + course1Grade + "+" + course2Grade + "+" + course3Grade + "+" + course4Grade + ")/4) = " + avg);
                                infoBox.appendText("\nYour Grade is B");
                            }
                            else if (avg >= 67 && avg < 77)
                            {
                                infoBox.clear();
                                infoBox.appendText("Your average score is: ((" + course1Grade + "+" + course2Grade + "+" + course3Grade + "+" + course4Grade + ")/4) = " + avg);
                                infoBox.appendText("\nYour Grade is C");
                            }
                            else if (avg >= 60 && avg < 67)
                            {
                                infoBox.clear();
                                infoBox.appendText("Your average score is: ((" + course1Grade + "+" + course2Grade + "+" + course3Grade + "+" + course4Grade + ")/4) = " + avg);
                                infoBox.appendText("\nYour Grade is D");
                            }
                            else if (avg >= 0 && avg < 60)
                            {
                                infoBox.clear();
                                infoBox.appendText("Your average score is: ((" + course1Grade + "+" + course2Grade + "+" + course3Grade + "+" + course4Grade + ")/4) = " + avg);
                                infoBox.appendText("\nYour Grade is F");
                            }
                            else
                            {
                                infoBox.appendText("Something is wrong");
                            }
                        }
                    }    
                   catch(NumberFormatException ex)
                   {
                       //error check was taken from https://www.javatpoint.com/numberformatexception-in-java
                        Alert wrongNumbers = new Alert(AlertType.ERROR);
                        wrongNumbers.setContentText("Insert only integer numbers from 0 to 100");
                        wrongNumbers.show();
                   }
                }
            }
        );
        
        //Show Statistics button
        showStats.setOnAction
        (
          new EventHandler<ActionEvent>()
            {
               @Override
               public void handle(ActionEvent event)
               {
                    try
                    {
                        //min max taken from https://stackoverflow.com/questions/19671453/how-do-i-get-the-max-and-min-values-from-a-set-of-numbers-entered
                        int tempMax1 = Math.max(Integer.parseInt(score1.getText()), Integer.parseInt(score2.getText()));
                        int tempMax2 = Math.max(Integer.parseInt(score3.getText()), Integer.parseInt(score4.getText()));
                        int realMax = Math.max(tempMax1, tempMax2);

                        int tempMin1 = Math.min(Integer.parseInt(score1.getText()), Integer.parseInt(score2.getText()));
                        int tempMin2 = Math.min(Integer.parseInt(score3.getText()), Integer.parseInt(score4.getText()));
                        int realMin = Math.min(tempMin1, tempMin2);



                        infoBox.clear();
                        infoBox.appendText("Your highest score is: " + realMax);
                        infoBox.appendText("\nYour lowest Score is: " + realMin);
                    }
                    catch (Exception e)
                    {
                        Alert wrongNumbers = new Alert(AlertType.ERROR);
                        wrongNumbers.setContentText("Insert only integer numbers from 0 to 100");
                        wrongNumbers.show();
                    }
               }
                    
            }
        );
        
        //Alert button
        alert.setOnAction
        (
          new EventHandler<ActionEvent>()
            {
                
               
               @Override
               public void handle(ActionEvent event)
               {
                   if(infoBox.getText().isEmpty() == false)
                   {
                       Alert showInfo = new Alert(AlertType.INFORMATION);
                       showInfo.setContentText(infoBox.getText());
                       showInfo.show();
                       
                   }
                   else
                   {
                       Alert infoAlert = new Alert(AlertType.ERROR);
                       infoAlert.setContentText("There is nothing to display");
                       infoAlert.show();
                   }
             
                   
                   
               }
                    
            }
        );
        
        
        //Clear All button
        clearAll.setOnAction
        (
          new EventHandler<ActionEvent>()
            {
               @Override
               public void handle(ActionEvent event)
               {
                   score1.clear();
                   score2.clear();
                   score3.clear();
                   score4.clear();
                   infoBox.clear();
                   
               }
                    
            }
        );
        
        
        
        //root.setGridLinesVisible(true);
        
        Scene scene = new Scene(root, width, height);
        
        primaryStage.setScene(scene);
        
        primaryStage.setTitle(title);
        primaryStage.show();
    }

   
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}

